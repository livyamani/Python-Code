# my_package/math_utils.py
def add(a, b):
    """Add two numbers."""
    return a + b

def subtract(a, b):
    """Subtract two numbers."""
    return a - b

def multiply(a, b):
    """Multiply two numbers."""
    return a * b

def divide(a, b):
    """Divide two numbers, handling division by zero."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
